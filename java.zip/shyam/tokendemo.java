import java.util.*;

public class TokenDemo
{
	public static void main(String args[])
	{
		StringTokenizer st=new StringTokenizer("I@love@myschool","@");
	
	while(st.hasMoreTokens())
	{
		System.out.println(st.nextToken());
	}
      }
}