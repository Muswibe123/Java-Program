import java.io.*;

class BufferedOutputStreamDemo
{
	public static void main(String args[])
	{
	try
	{
		FileOutputStream fos=new FileOutputStream("demo.txt");
		BufferedOutputStream bos=new BufferedOutputStream(fos);

		for(int i=0;i<12;i++)
		{
			bos.write(i);
		}
		bos.close();
		fos.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
 	}
}