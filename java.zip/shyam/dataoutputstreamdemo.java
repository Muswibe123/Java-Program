import java.io.*;

class DataOutputStreamDemo
{
	public static void main(String args[])
	{
		try
		{
		FileOutputStream fos=new FileOutputStream("datafile.txt");
		DataOutputStream dos=new DataOutputStream(fos);

		dos.writeBoolean(false);
		dos.writeByte(Byte.MAX_VALUE);
		dos.writeChar('a');
		dos.writeDouble(Double.MAX_VALUE);
		dos.writeFloat(Float.MAX_VALUE);
		dos.writeInt(Integer.MAX_VALUE);
		dos.writeLong(Long.MAX_VALUE);
		dos.close();
		fos.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
