import java.util.*;
	
class LinkedHashMap2
{
	public static void main(String args[])
	{
		LinkedHashMap<Integer,String>map=new LinkedHashMap<Integer,String>();
	
	map.put(103,"Amit");
	map.put(101,"Vijay");
	map.put(102,"Rahul");

	System.out.println("keys:"+map.keyset());

	System.out.println("Values:"+map.values());

	map.remove(101);

	System.out.println("key-value pairs:"+map.entrySet());
}}