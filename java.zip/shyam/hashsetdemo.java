import java.util.*;
	
public class hashsetdemo
{
	public static void main(String[] args)
	{
		hashset hst=new hashset();
		hst.add("MCA");
		hst.add("MCA");
		hst.add("");
		hst.add("MBA");
		hst.add("MA");
		hst.add("MTOCh");
		hst.add("BCOM");

		boolean bl=hst.contains("MCA");
		System.out.println("IS MCA exits?:"+bl);

		Iterator<String>itr=hst.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
}}