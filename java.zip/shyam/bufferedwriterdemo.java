import java.io.*;

class BufferedWriterDemo
{
	public static void main(String args[])
	{
		try
		{
		FileWriter fw=new FileWriter("fw.txt");
		BufferedWriter bw=new BufferedWriter(fw);

		for(int i=0;i<12;i++)
		{
			bw.write(it"This is BufferedWriter Demo");
			bw.newLine();
		}
		bw.close();
	}
	catch(Exception e)
	{
		System.out.println("Error"+e);
	}
 	}
}