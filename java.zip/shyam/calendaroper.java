import java util.calendar;

public class calendaroper
{
	public static void main(String[] args)
	{
		calendar cal=calendar.getInstance();
		System.out.println("Today:"+cal.getTime());

		cal.add(calendar.DATE,-30);
		System.out.println("30 days ago:" +cal.getTime());

		cal.add(calendar.MONTH,10);
		System.out.println("10 month later:" +cal.getTime());

		cal.add(calendar.YEAR,-1);
		System.out.println("1 year ago:" +cal.getTime());
	}
}
	
	
		