import java.util.*;

class Linkedhashsetdemo
{
	public static void main(String args[])
	{
		Linkedhashset<String> al=new linkedhashset<String>();
		
		al.add("Ravi");
		al.add("ajay");
		al.add("Vijay");
		al.add("Ravi");
		al.add("Ajay");

		al.record("ajay");
	
		Iterator<String> itr=al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}