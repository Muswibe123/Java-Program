import java.text.*;
import java.util.*;

public class Dateformatter
{
	public static void main(String args[])
	{
		String s;
		format formatter;
		Date date=new Date();

		formatter=new simpledateformat("MM/dd/yy");
		s=formatter.format(date);
		System.out.println(s);
		
		formatter=new simpledateformat("dd/MM/yy");
		s=formatter.format(date);
		System.out.println(s);

		formatter=new simpledateformat("dd-MMM-yy");
		s=formatter.format(date);
		System.out.println(s);

		formatter=new simpledateformat("yyyy.MM.dd.HH.mm.ss");
		s=formatter.format(date);
		System.out.println(s);

		formatter=new simpledateformat("E,dd MMM yyy HH:mm:ss");
		s=formatter.format(date);
		System.out.println(s);

		formatter=new simpledateformat("EEEE,dd MMMM yyyy HH:mm:ss zz");
		s=formatter.format(date);
		System.out.println(s);
	}
}


		