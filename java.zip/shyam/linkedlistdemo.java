import java.util.*;

public class LinkedListDemo
{
	public static void main(String args[])
	{
		LinkedListld1=new LinkedList();
		
	|ld1.add("F");
	ld1.add("B");
	ld1.add("D");
	ld1.add("E");
	ld1.add("C");
	ld1.add("Z");
	ld1.add("A");
	ld1.add(1,"A2");
	System.out.println("\n Original contents of linkedlist:"+ld1);
	
	ld1.add("F");
	ld1.remove(2);

	System.out.println("contents of ld1 after delection:"+ld1);

	ld1.removefirst();
	ld1.removelast();
	
	System.out.println("ld1 after deleting first and last:"+ld1);
	}
}