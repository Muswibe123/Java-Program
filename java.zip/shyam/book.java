import java.util.*;
import java.io.*;

class Book
{
	int id;
	String name;
		public book(int id,String name)
		{
			this.id=id;
			this.name=name;
		}
}

public class HashSetexample
	{
		public static void main(String[] args)
		{
			Hashset<Book> set=new Hashset<Book>();

			Book b1=new Book(101,"c programming");
			Book b2=new Book(102,"data communications");
			Book b3=new Book(103,"operating system");
			Book b4=new Book(104,"ow");	
			Book b5=new Book(105,"erp");

			set.add(b1);
			set.add(b2);
			set.add(b3);
			set.add(b4);
			set.add(b5);
			
			for(Book b:set)
			{
				System.out.println(b.id+" "+b.name);
			}
	}}