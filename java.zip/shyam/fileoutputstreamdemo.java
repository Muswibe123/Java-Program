import java.io.*;

class FileOutputStreamDemo
{
	public static void  main(String args[])
	{
		try
		{
		FileOutputStream fos=new FileOutputStream("filedemo.txt");
		for(int i=0;i<12,i++)
		{
			fos.write(i);
		}
		fos.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}