import java.util.*;

public class Arraydequeexample
{
	public static void main(String[] args)
	{
	Arrraydeque<String>dq=new Arraydeque<String>();

	dq.offer("arvind");
	dq.offer("vimal");
	dq.offer("mukal");
	dq.offer("jatin");

	dq.offerfirst("jai");
	dq.offerlast("vijay");

	System.out.println("after offerfirst and offerlast traversal..");

	for(String s;dq)
	{
		System.out.println(s);
	}

	dq.poll();
	dq.polllast();

	System.out.println("======");
	System.out.println("After pollfirst() & polllast() traversal...");
	
	for(String s:dq)
	{
		System.out.println(s);
	}
}























