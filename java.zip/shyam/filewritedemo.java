import java.io.*;

class fileWriteDemo
{
public static void main(String args[])
{
	try	
	{
	Filewrite fw=new FileWriter("BCA4.txt");
	fw.write("I like java");
	fw.write("\n \n \t I like HTML");
	}
	catch(Exceptione)
	{
	System.out.println(e);
	}
	System.out.println("success");
}