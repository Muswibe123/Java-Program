import java.util.*;

class Gregorian calendarDemo
{
	public static void main(String[] args)
{

calendar cal=new Gregorian calendar();

System.out.println("Day of Month"+cal.get(cal.DAY_OF_MONTH));

System.out.println("Day of Week"+cal.get(cal.DAY_OF_WEEK));

System.out.println("Week of Year"+cal.get(cal.WEEK_OF_YEAR));

System.out.println("Week of Month"+cal.get(cal.WEEK_OF_MONTH));

System.out.println("Hour"+cal.get(cal.HOUR));

System.out.println("Hour of Day"+cal.get(cal.HOUR_OF_DAY));

System.out.println("Minute"+cal.get(cal.MINUTE));
System.out.println("Second"+cal.get(cal.SECOND));
System.out.println("MillSecond"+cal.get(cal.MILLSECOND));

System.out.println("Year:"+cal.get(cal.YEAR));
System.out.println("Month:"+cal.get(cal.MONTH)+11);
System.out.println("Day:"+cal.get(cal.DAY_OF_MONTH));

}

}

























