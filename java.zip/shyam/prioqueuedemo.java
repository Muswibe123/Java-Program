import java.util.*;

class prioQueueDEmo
{
	public static void main(String args[]){
	
	priority Queue<String>queue=new priorityQueue<String>();

	queue.add("D");
	queue.add("B");
	queue.add("C");
	queue.add("E");
	queue.add("F");

	System.out.println("head(top)element:"+queue.element());

	System.out.println("iterating the queue element:");

	Iterator itr=queue.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}

	System.out.println("removed top 2 elements,now new head element is:"+queue.element());

	System.out.println("after removing two elements:");
	
	Iterator itr2=queue.iterator();
	while(itr2.hasNext())
	{
		System.out.println(itr2.next());
	}
	}
}
	