import java.util.*;
import java.io.*;

class DayMonthTest
{
	public static void main(String args[])
	{
		

	Scanner scan=new Scanner(System.in)

	System.out.println("Enter Total Days");
	int day=scan.nextInt();

	int mon=day/30;
	int tdy=day%30;
	System.out.println(day+"Days="mont"month and +tdy+"days");
	}
}