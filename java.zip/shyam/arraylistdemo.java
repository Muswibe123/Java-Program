import java.util.*;

class ArarayListDemo
{

	public static void main(String args[])
	{
		ArrayList<String>list=new ArrayList<String>();

		list.add("ravi");
		list.add("vijay");
		list.add("ravi");
		list.add("ajay");

	list.remove(2);
		
		Iterator itr=list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}
