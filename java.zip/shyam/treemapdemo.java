import java.util.*;

public class TreeMapDemo
{
	public static void main(String[] args)
	{
		System.out.println("Tree Map Example!\n");
		TreeMap tMap=new TreeMap();

		tMap.put(1,"Sunday");
		tMap.put(2,"Tuesday");
		tMap.put(3,"Monday");
		tMap.put(4,"Wednesday");
		tMap.put(5,"Thursday");
		tMap.put(6,"Friday");
		tMap.put(7,"Saturday");

	System.out.println("Keys of tree of tree map:"+ +Map.keysset());

	System.out.println("Values of tree map:"+ +Map.values());

	System.out.println("key:S value:"+ +Map.get(s)+"\n");

	System.out.println("First key:"+ +Map.firstkey()+"value:"+ +Map.get(+Map.firstkey())+"\n");
	
	System.out.println("Last key:"+ +Map.lastkey()+"value:"+ +Map.get(+Map.lastkey())+"\n");

	System.out.println("Removing first data:"+ +Map.firstkey()));

	System.out.println("Removing last data:"+ +Map.remove(+Map.lastkey()));

	System.out.println("Now the tree map keys:"+ +Map.keyset());

	System.out.println("Now the tree map contain:"+ +Map.values());
	}
}