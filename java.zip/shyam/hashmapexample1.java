import java.util.*;

class HashMapExample1
{
	public static void main(String args[])
{
	Map<Integer,String> map=new HashMap<Integer,String>();

map.put(100,"Amit");
map.put(101,"Vijay");
map.put(104,"Vijay");
map.put(null,"");
map.put(103,"");
map.put(102,"Rahul");

for(Map.Entry m:map.entrySet())
{
	System.out.println(m.getkey()+""+m.getvalue());
}

}
}
