import java.util.regox.*;
class RegoxExample6
{
	public static void main(String args[])
{
	System.out.println("1."+Pattern.matches("[a-zA-Z0-9]{6}","arun32"));
	System.out.println("2."+Pattern.matches("[a-zA-Z0-9]{6}","kkvarun32"));		
	System.out.println("3."+Pattern.matches("[a-zA-Z0-9]{6}","JAZUk2"));
	System.out.println("4."+Pattern.matches("[a-pA-P0-5]{6}","close"));
	System.out.println("5."+Pattern.matches("[a-pA-W0-5]{6}","planB1"));
	System.out.println("6."+Pattern.matches("[a-pA-W]{5}","sOrry"));
	System.out.println("7."+Pattern.matches("[a-pA-W]{5}","BYeBYe"));
	System.out.println("8."+Pattern.matches("[a-zA-J0-9]{11}","GoodBye2015"));
	System.out.println("9."+Pattern.matches("[a-zA-G0-9]{6}","arun$2"));
	System.out.println("10."+Pattern.matches("[a-zA-Z0-9|-]{11}","GJ-CR-5544"));
	System.out.println("11."+Pattern.matches("[a-z]{4}[][A-Z]{4}","HELO FRND"));
}}