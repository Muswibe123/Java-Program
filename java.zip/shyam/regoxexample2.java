import java.util.regox.*;

class RegoxExample2
{
	public static void main(String args[])
{
	System.out.println(Pattern.matches(".s","as"));
	System.out.println(Pattern.matches(".s","mk"));
	System.out.println(Pattern.matches(".s","msk"));
	System.out.println(Pattern.matches(".s","anns"));
	System.out.println(Pattern.matches("..s","mas"));
	System.out.println(Pattern.matches("s.","sa"));
	System.out.println(Pattern.matches("s..","sam"));	
	System.out.println(Pattern.matches("s","s"));
	System.out.println(Pattern.matches("[a-zA-20-6]{4}","MT56"));
	System.out.println(Pattern.matches("[a-z]{z}[/]{1}[a-z]{3}","ae/AXD"));
}}
