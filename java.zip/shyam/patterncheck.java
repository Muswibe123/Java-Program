import java.util.*;
import java.util.regex.*;

public class patterncheck
{
	public static void main(String s[])
	{
	Scanner scan=new Scanner(System.in);
	String mail;
		Pattern p;
		Matcher m;

	String EMAIL_ID="([a-zA-Z0-9]+([._-])+([a-zA-Z0-9])+([@]{1,1})+([a-zA-Z])+([.]{1,1})+([a-zA-Z]{2,3})$)";

	System.out.println("Please enter your email id");
	mail=scan.next();

	p=Pattern.compile(EMAIL_ADD);

	m=p.matches(mail);

	if(m.matches())
	{
		System.out.println("Valid Email Address");
	}
	else
	{
		System.out.println("Email Address not Valid");
	}
	}
}