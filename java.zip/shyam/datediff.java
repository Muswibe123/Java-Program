import java.util.*;
import java.text.*;

class datediff
{
	public static void main(String args[])
	{
	String fdt,mdt;
	
	Scanner scan=new Scanner(System.in);
	
	System.out.println("Enter your friends Bdate in MM/dd/yyyy format");
	fdt=scan.next();

	System.out.println("Enter your  Bdate in MM/dd/yyyy format");
	mdt=scan.next();

	SimpleDateFormat fmt=new SimpleDateFormat ("MM/dd/yyyy");

	long msdiff,diffday;
		
	try
	{
		Date d1=fmt.parse(fdt);
		Date d2=fmt.parse(mdt);
		
		msdiff=d1.getTime()-d2.get.Time();
		diffday=msdiff;
		
		System.out.println("\n total days difference between you & your friends are"+diffday);
		
		if(d1.after(d2))
		{
			System.out.println("you are elder than your friend");
		}
		else
		{
			System.out.println("you friend is elder than you");
		}

		}
		catch(Exception e)
		{
		e.printstacktrace();
		}
	}
}